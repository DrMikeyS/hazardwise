import{av as a}from"./BITUO3ds.js";a();
